package pe.edu.pucp.sisrap.planificador.dominio.modelo;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import pe.edu.pucp.sisrap.almacen.dominio.Almacen;
import pe.edu.pucp.sisrap.flota.dominio.Vehiculo;
import pe.edu.pucp.sisrap.parametros.dominio.ReglasPlanificacion;
import pe.edu.pucp.sisrap.pedido.dominio.Pedido;

public record ContextoPlanificacion(
        List<Pedido> pedidos,
        List<Vehiculo> vehiculos,
        List<Almacen> almacenes,
        LocalDateTime instante,
        ReglasPlanificacion reglas,
        Set<String> nodosBloqueados,
        boolean respetarPosicionVehiculo,
        java.util.List<pe.edu.pucp.sisrap.experimentacion.dominio.Bloqueo> calendarioBloqueos,
        java.util.Map<String, LocalDateTime> disponibleHasta) {

    public ContextoPlanificacion {
        disponibleHasta = disponibleHasta == null ? java.util.Map.of() : java.util.Map.copyOf(disponibleHasta);
        calendarioBloqueos = calendarioBloqueos == null ? List.of() : List.copyOf(calendarioBloqueos);
        pedidos = List.copyOf(pedidos);
        vehiculos = List.copyOf(vehiculos);
        almacenes = List.copyOf(almacenes);

        if (almacenes.isEmpty() || instante == null || reglas == null) {
            throw new IllegalArgumentException("Contexto incompleto");
        }

        nodosBloqueados = nodosBloqueados == null
                ? Set.of()
                : Set.copyOf(nodosBloqueados);

        var ids = new HashSet<Long>();
        for (var p : pedidos) {
            if (!ids.add(p.getIdPedido())) {
                throw new IllegalArgumentException("Pedido duplicado");
            }

            if (p.getFechaDisponiblePlanificacion().isAfter(instante)) {
                throw new IllegalArgumentException("No se pueden anticipar pedidos futuros");
            }
        }

        if (vehiculos.stream()
                .map(Vehiculo::getIdVehiculo)
                .distinct()
                .count() != vehiculos.size()) {
            throw new IllegalArgumentException("Vehículo duplicado");
        }
    }

    public ContextoPlanificacion(List<Pedido> pedidos, List<Vehiculo> vehiculos,
            List<Almacen> almacenes, LocalDateTime instante, ReglasPlanificacion reglas,
            Set<String> nodosBloqueados, boolean respetarPosicionVehiculo,
            java.util.List<pe.edu.pucp.sisrap.experimentacion.dominio.Bloqueo> calendarioBloqueos) {
        this(pedidos, vehiculos, almacenes, instante, reglas, nodosBloqueados,
                respetarPosicionVehiculo, calendarioBloqueos, java.util.Map.of());
    }

    public ContextoPlanificacion(List<Pedido> pedidos, List<Vehiculo> vehiculos,
            List<Almacen> almacenes, LocalDateTime instante, ReglasPlanificacion reglas,
            Set<String> nodosBloqueados, boolean respetarPosicionVehiculo) {
        this(pedidos, vehiculos, almacenes, instante, reglas, nodosBloqueados,
                respetarPosicionVehiculo, List.of());
    }

    /** Compatibilidad total con la experimentación existente. */
    public ContextoPlanificacion(
            List<Pedido> pedidos,
            List<Vehiculo> vehiculos,
            List<Almacen> almacenes,
            LocalDateTime instante,
            ReglasPlanificacion reglas,
            Set<String> nodosBloqueados) {
        this(
                pedidos,
                vehiculos,
                almacenes,
                instante,
                reglas,
                nodosBloqueados,
                false);
    }

    /** Compatibilidad total con la experimentación existente. */
    public ContextoPlanificacion(
            List<Pedido> pedidos,
            List<Vehiculo> vehiculos,
            List<Almacen> almacenes,
            LocalDateTime instante,
            ReglasPlanificacion reglas) {
        this(
                pedidos,
                vehiculos,
                almacenes,
                instante,
                reglas,
                Set.of(),
                false);
    }

    public List<Pedido> getPedidos() { return pedidos; }
    public List<Vehiculo> getVehiculos() { return vehiculos; }
    public List<Almacen> getAlmacenes() { return almacenes; }
}
